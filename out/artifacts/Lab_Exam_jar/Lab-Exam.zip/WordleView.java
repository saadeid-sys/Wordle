public interface WordleView {
    void update(WordleEvent e);
}
